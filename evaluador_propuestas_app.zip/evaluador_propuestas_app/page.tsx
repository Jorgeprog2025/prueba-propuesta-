
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";

export default function EvaluacionPropuestasApp() {
  return (
    <div className="p-4 md:p-10 space-y-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold">Evaluador Inteligente de Propuestas Públicas</h1>

      <Card className="p-4">
        <CardContent className="space-y-4">
          <h2 className="text-xl font-semibold">Subir Propuesta</h2>
          <Input type="file" accept=".pdf,.docx,.txt" />
          <Button>Cargar y Evaluar</Button>
        </CardContent>
      </Card>

      <Tabs defaultValue="resultado" className="w-full">
        <TabsList>
          <TabsTrigger value="resultado">Resultado</TabsTrigger>
          <TabsTrigger value="detalle">Detalle Evaluación</TabsTrigger>
          <TabsTrigger value="comparar">Comparar</TabsTrigger>
        </TabsList>

        <TabsContent value="resultado">
          <Card className="p-4">
            <CardContent>
              <h3 className="text-lg font-semibold">Puntaje Total: 82%</h3>
              <Progress value={82} className="my-4" />
              <p>La propuesta tiene alta viabilidad técnica y buen impacto social.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="detalle">
          <Card className="p-4">
            <CardContent className="space-y-3">
              <h3 className="text-lg font-semibold">Evaluación por criterios:</h3>
              <ul className="list-disc list-inside">
                <li>Viabilidad Técnica: 90%</li>
                <li>Impacto Social: 85%</li>
                <li>Riesgos: 60%</li>
                <li>Legalidad: 100%</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="comparar">
          <Card className="p-4">
            <CardContent>
              <p>Comparar con otras propuestas evaluadas...</p>
              <Button variant="secondary">Cargar comparativa</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card className="p-4">
        <CardContent>
          <h2 className="text-xl font-semibold">Observaciones Generadas por IA</h2>
          <Textarea readOnly value="La propuesta destaca por su enfoque innovador en educación rural..." />
        </CardContent>
      </Card>
    </div>
  );
}
