# Evaluador Propuestas App

Aplicación en React para evaluar propuestas públicas con IA.
